package player;

enum Direction {north, east, south, west}
