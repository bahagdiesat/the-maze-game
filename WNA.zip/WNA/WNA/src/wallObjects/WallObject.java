package wallObjects;

public abstract class WallObject {
    public abstract String getObjectName();

}
