package wallObjects;

import Items.Item;

import java.util.List;

public interface Checkable {
    List<Item> check();
}
