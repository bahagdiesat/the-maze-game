package Items;

public abstract class Item {
    public abstract Gold getPrice();

    public abstract String getName();
}
